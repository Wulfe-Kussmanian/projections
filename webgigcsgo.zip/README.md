# CS:GO Website

Read the documentation.txt for information about how to tailor the site to your needs.
